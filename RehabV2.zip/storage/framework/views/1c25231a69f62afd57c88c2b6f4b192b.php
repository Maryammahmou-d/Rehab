<!doctype html>
<html lang="en" data-theme="<?php echo e(config('scramble.theme', 'light')); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e(config('app.name')); ?> - API Docs</title>

    <script src="https://unpkg.com/@stoplight/elements/web-components.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/@stoplight/elements/styles.min.css">
</head>
<body style="height: 100vh; overflow-y: hidden">
<elements-api
    apiDescriptionUrl="<?php echo e(route('scramble.docs.index')); ?>"
    tryItCredentialsPolicy="<?php echo e(config('scramble.ui.try_it_credentials_policy', 'include')); ?>"
    router="hash"
    <?php if(config('scramble.ui.hide_try_it')): ?> hideTryIt="true" <?php endif; ?>
    logo="<?php echo e(config('scramble.ui.logo')); ?>"
/>
</body>
</html>
<?php /**PATH /home/mahmoud/Desktop/Empty-Project-Auth-jetstream/vendor/dedoc/scramble/src/../resources/views/docs.blade.php ENDPATH**/ ?>