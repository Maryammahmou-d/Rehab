<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RolesPermissonsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly Role.
     */

    public function store_role(Request $request)
    {
        $role = Role::create(['name' => $request->role]);
        return response()->json(["Role Created"]);
    }


    /**
     * Store a Newly Permisson.
     */

    public function store_permisson(Request $request)
    {
        $permission = Permission::create(['name' =>  $request->permisson]);
        return response()->json(["Permisson Created"]);
    }



    /**
     * Assign Permisson To Role.
     */

    public function assign_permisson(Request $request)
    {

        // Assuming $request->role contains the role name or id
        $role = Role::findByName($request->role);

        if (!$role) {
            return response()->json(['error' => 'Role not found'], 404);
        }

        $permission = $request->permission;

        // Assuming $permission is the name of the permission
        $role->givePermissionTo($permission);

        return response()->json(['role' => $role]);
    }

    /**
     * Add role to user
     */

    public function assign_role(Request $request)
    {
        $role = Role::findByName($request->role);
        $user = User::find($request->user_id);
        if (!$role) {
            return response()->json(['error' => 'Role not found.'], 404);
        } else {
            $user->assignRole($role);
            return response()->json(["Role was added Successfully"]);
        }
    }



    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
