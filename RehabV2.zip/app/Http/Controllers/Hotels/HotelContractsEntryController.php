<?php

namespace App\Http\Controllers\Hotels;
use App\Http\Controllers\Controller;

use App\Models\HotelContractsBuyer;
use App\Models\HotelContractsEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class HotelContractsEntryController extends Controller
{

    public function index()
    {
    // $user = auth()->user();
    // if (!$user) {
    //     return response()->json(['message' => 'Unauthorized'], 401);
    // }
    // $organizationId = $user->org_id;
        $organizationId = 1;
        $buyers = HotelContractsEntry::where('org_id', $organizationId)->get();
        $contracts = HotelContractsBuyer::where('org_id', $organizationId)->get();
        return response()->json([
            'status' => 'success',
            'data' => $buyers,
            'contracts' => $contracts
        ], 200);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'hotel_id' => 'required|integer',
            'rooms_needed' => 'nullable|integer',
            'rooms_type' => 'nullable|string',
            'pilgrims' => 'nullable|integer',
            'group_name' => 'nullable|string',
            'nusuk_id' => 'nullable|string',
            'start_date' => 'nullable|date',
            'end_date' => 'nullable|date',
            'hotel_cost' => 'nullable|numeric',
            'room_cost' => 'nullable|numeric',
            'meal_cost' => 'nullable|numeric',
            'days_meals' => 'nullable|numeric',
            'food_cost' => 'nullable|numeric',
            'hotel_cost_1person' => 'nullable|numeric',
            'food_cost_1person' => 'nullable|numeric',
            'org_id' => 'required|integer|exists:organizations,id',
            'status' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $hotelContractEntry = new HotelContractsEntry($validator->validated());
        $hotelContractEntry->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Hotel contract entry created successfully!',
            'data' => $hotelContractEntry
        ], 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(HotelContractsEntry $hotelContractsEntry)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(HotelContractsEntry $hotelContractsEntry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, HotelContractsEntry $hotelContractsEntry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(HotelContractsEntry $hotelContractsEntry)
    {
        //
    }
}
