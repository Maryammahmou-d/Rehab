<?php

namespace App\Http\Controllers;

use App\Models\organizations;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class OrganizationsController extends Controller
{

    /**
     * 
     * Auth for Org
     * 
     */


     public function login(Request $request)
     {
         $credentials = $request->only('email', 'password');
 
         if (Auth::guard('org')->attempt($credentials)) {
             // Authentication was successful
             return response()->json(["Done"]);
         }
 
         // Authentication failed
         return redirect()->back()->withErrors([
             'email' => 'The provided credentials do not match our records.',
         ]);
     }


    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Display all users belong to this ORG.
     */
    public function team($id)
    {
        $orgs = organizations::find($id);
        if ($orgs) {
            $users = User::where('org_id' , $id)->get();
            return response()->json($users);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
