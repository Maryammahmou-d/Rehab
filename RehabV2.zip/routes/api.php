<?php

use App\Http\Controllers\AuthApiController;
use App\Http\Controllers\Hotels\HotelContractsBuyerController;
use App\Http\Controllers\Hotels\MissedHotelController;
use App\Http\Controllers\Hotels\HotelContractsEntryController;
use App\Models\HotelContractsEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\OrganizationsController;
use App\Http\Controllers\RolesPermissonsController;
use App\Http\Controllers\AirlinesController;
use App\Http\Controllers\Admin\UsersController;
use App\Http\Controllers\Admin\CompaniesController;
use App\Http\Controllers\PackageController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/auth/login', [AuthApiController::class, 'login']);
Route::post('/auth/register', [AuthApiController::class, 'register']);


// Route::middleware(['checkIfAdmin'])->prefix('admin')->group(function () {
    Route::post('/role/create', [RolesPermissonsController::class, 'store_role']);
    Route::post('/permisson/create', [RolesPermissonsController::class, 'store_permisson']);
    Route::post('/assign/permisson', [RolesPermissonsController::class, 'assign_permisson']);
    Route::post('/assign/role', [RolesPermissonsController::class, 'assign_role']);

// });




// Route::middleware(['checkIfAdmin'])->prefix('organization')->group(function () {
    Route::get('/index', [OrganizationsController::class, 'index']);
    Route::get('/team/{id}/all', [OrganizationsController::class, 'team']);
    Route::post('/org/login', [OrganizationsController::class, 'login']);

// });





// Route::middleware(['checkIfHotelBuyer'])->group(function () {
    Route::get('/hotel-contracts-buyers', [HotelContractsBuyerController::class, 'index']);
    Route::post('/hotel-contracts-buyers/store', [HotelContractsBuyerController::class, 'store']);
    Route::get('/hotel-contracts-buyers/{id}/get', [HotelContractsBuyerController::class, 'show']);
    Route::post('/hotel-contracts-buyers/{id}/update', [HotelContractsBuyerController::class, 'update']);
    Route::get('/hotel-contracts-buyers/{id}/delete', [HotelContractsBuyerController::class, 'destroy']);
    Route::post('/hotel-contracts-buyers/{id}/split', [HotelContractsBuyerController::class, 'split']);


    Route::get('/hotel-contracts-entry', [HotelContractsEntryController::class, 'index']);
    Route::post('/hotel-contracts-entry/store', [HotelContractsEntryController::class, 'store']);
// });

Route::post('/missed-hotel/store', [MissedHotelController::class, 'store']);

// Route::middleware(['checkIfAirline'])->group(function () {

Route::get('/airlines-booking', [AirlinesController::class, 'index']);
Route::post('/airlines-booking/store', [AirlinesController::class, 'store']);
// });

// Route::middleware(['checkIfAdmin'])->prefix('admin')->group(function () {
    Route::get('/users', [UsersController::class, 'index']);
    Route::get('/user/{id}/view', [UsersController::class, 'show']);
    Route::post('/user/{id}/update', [UsersController::class, 'update']);

    Route::get('/companies', [CompaniesController::class, 'index']);

// });



Route::get('/packages', [PackageController::class, 'index']);
Route::post('/packages/store', [PackageController::class, 'store']);
Route::post('/packages/{id}/update', [PackageController::class, 'update']);
